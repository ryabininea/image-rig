self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b52f151e53a19b61326e798d825449be",
    "url": "/index.html"
  },
  {
    "revision": "3277ea5618d870f806bc",
    "url": "/static/css/2.09e62520.chunk.css"
  },
  {
    "revision": "3277ea5618d870f806bc",
    "url": "/static/js/2.82a9c8b1.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.82a9c8b1.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d3951371504f96cd198b",
    "url": "/static/js/main.9c818856.chunk.js"
  },
  {
    "revision": "2f729f8dfb644b1198eb",
    "url": "/static/js/runtime-main.4146942f.js"
  }
]);